/*class P4
{
    public static void main(String args[])
     {
        int row=9;
        int space=row;
        for(int i=1;i<=row;i++)
        {
            int c=1;
            for(int j=1;j<=space;j++)
            {
                System.out.print("  ");
                
            }
            space--;
            for(int k=1;k<=i;k++)
            {
                System.out.print(+c+" ");
                c++;
            }
            c=c-2;
            for(int m=2;m<=i;m++)
            {
                System.out.print(+c+" ");
                c--;
            }
            System.out.println();
        } 
       
     }
}
*/
class P4
{
    public static void main(String args[])
     {
        int row=9;
        
        for(int i=1;i<=row;i++)
        {
            int c=1;
            for(int j=row;j>=i;j--)
            {
                System.out.print("  ");
                
            }
            for(int k=1;k<=i;k++)
            {
                System.out.print(+c+" ");
                c++;
            }
            c=c-2;
            for(int m=2;m<=i;m++)
            {
                System.out.print(+c+" ");
                c--;
            }
            System.out.println();
        } 
       
     }
}
           
          
           