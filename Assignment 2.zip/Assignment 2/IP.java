// Half Inverted Pyramid

class IP
{
  public static void main(String args[])
  {
    int min=1;
    int max=6;

    for(int i=max;i>=min;i--)
     {
        for(int j=min;j<=i;j++)
          {
             if(i<max)
               { 
                    if(j==min || j==i) 
                       System.out.print("* ");
                    else
                       System.out.print("  ");
               }
              else System.out.print("* ");
          }
        System.out.println();
        }
  }
}