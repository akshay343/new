// Inverted Half Pyramid

/*class IHP
{
   public static void main(String args[])
    {
       for(int i=6;i>=1;i--)
       {
         for(int j=1;j<=i;j++)
          {
            System.out.print("* ");
          }
         System.out.println();
       }
    }
}
*/
class IHP
{
   public static void main(String args[])
    {
       for(int i=1;i<=6;i++)
       {
         for(int j=6;j>=i;j--)
          {
            System.out.print("* ");
          }
         System.out.println();
       }
    }
}
